import { Container, Sprite, Assets } from 'pixi.js';
import { TextPopup } from './TextPopup.js';

export class TutorialManager extends Container {
  constructor(game) {
    super();

    this.game = game;
    this.active = false;
    this.currentStep = null;
    this.zIndex = 1000;

    // рука
    this.hand = new Sprite(Assets.get('hand'));
    this.hand.anchor.set(0.5);
    this.hand.scale.set(0.06);
    this.hand.visible = false;
    this.hand.zIndex = 1022;
    this.addChild(this.hand);

    this.textPopup = null;

    // ловим тап
    this.eventMode = 'static';
    this.on('pointerup', this.onTap.bind(this));
    this.on('touchend', this.onTap.bind(this));
  }

  // ===== СТАРТОВЫЙ ТУТОРИАЛ =====
  startIntro() {
    if (this.active) return;

    this.active = true;
    this.game.gamePaused = true;
    this.game.flagJump = false;
    this.game.player.playIdle();

    // рука по центру
    this.hand.visible = true;
    this.hand.x = this.game.DESIGN_W / 2;
    this.hand.y = this.game.DESIGN_H / 2 + 190;

    // текст
    this.textPopup = new TextPopup(
      'Tap to start earning!',
      this.hand.x,
      this.hand.y - 250,
      45
    );
    this.addChild(this.textPopup);
  }

  // ===== ВРАГ =====
  startEnemyTutorial() {
    if (this.active) return;
    
    this.active = true;
    this.game.gamePaused = true;
    this.game.flagJump = true;
    this.hand.visible = true;
    this.hand.x = this.game.DESIGN_W / 2;
    this.hand.y = this.game.DESIGN_H / 2 - 40;

    this.textPopup = new TextPopup(
      'Jump to avoid enemies!',
      this.hand.x,
      this.hand.y - 120,
      50
    );

    this.addChild(this.textPopup);
    this.game.gamePaused = true;
  }

  // ===== ТАП =====
  onTap() {
    if (!this.active) return;

    this.active = false;
    this.game.gamePaused = false;
    this.hand.visible = false;
    this.game.player.playRun();

  }

  update(delta) {
    if (this.textPopup) {
      // ⬅ ПРОВЕРЯЕМ, НЕ УНИЧТОЖЕН ЛИ ТЕКСТ
      if (this.textPopup.destroyed) {
        this.textPopup = null;
        return;
      }
      
      this.textPopup.update(delta);
      
      // ⬅ ПРОВЕРЯЕМ ПОСЛЕ ОБНОВЛЕНИЯ
      if (this.textPopup && this.textPopup.life <= 0) {
        this.textPopup = null;
      }
    }
  }
}
