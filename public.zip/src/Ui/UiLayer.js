import { Container, Sprite, Assets } from 'pixi.js';

export class UiLayer extends Container {
    constructor() {
        super();

        // Панелька в нижний левый угол
        this.playoffPanel = new Sprite(Assets.get('playoff'));
        this.addChild(this.playoffPanel);

        // Изначальная позиция, потом обновим при ресайзе
        this.playoffPanel.x = 0;
        this.playoffPanel.y = 0;
    }

    // Метод для обновления позиции при ресайзе
    resize(appWidth, appHeight) {
        // Нижний левый угол
        this.playoffPanel.x = 20; // небольшой отступ от края
        this.playoffPanel.y = appHeight - this.playoffPanel.height - 20;
    }
}
