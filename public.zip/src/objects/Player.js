import { Sprite, Assets } from 'pixi.js'; 

export class Player extends Sprite {
  constructor() {
   
    // Способ 1: Если текстура уже загружена через Assets
    const texture = Assets.get('player');
    
    if (!texture) {
      console.warn('Player texture not loaded yet');
      super(); // Создаем спрайт без текстуры
    } else {
      super(texture);
    }
    
    this.anchor.set(0.5); // центр спрайта по x и y
    this.scale.set(0.25);
    
    // Оптимизации для playable ads
    this.roundPixels = true;
    this.batchable = true;
  }

  update(time) {
    // Можно добавить движение или анимацию
    const delta = time?.deltaTime || 1;
    
    // Пример простой анимации
    // this.rotation += 0.01 * delta;
  }
  
  // Дополнительные методы
  start() {
    // Запуск анимации/движения
    console.log('Player started');
  }
  
  pause() {
    // Пауза
    console.log('Player paused');
  }
  
  reset() {
    // Сброс состояния
    this.x = 0;
    this.y = 0;
    this.rotation = 0;
  }
}